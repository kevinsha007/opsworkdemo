#
# Cookbook:: opsworks_cookbook_demo
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved.
Chef::Log.info("********** Hello, World! **********")