directory "Create a directory" do
  group "root"
  mode "0755"
  owner "jdoe"
  path "/tmp/create-directory-demo"  
end