user "Add a user" do
  home "/home/jdoe"
  shell "/bin/bash"
  username "jdoe"  
end