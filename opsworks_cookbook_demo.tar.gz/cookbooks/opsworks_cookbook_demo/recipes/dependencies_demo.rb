application "Install NetHack" do
  package "nethack-x11"
end